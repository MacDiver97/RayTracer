#include "StdAfx.h"
#include "SceneObject.h"


CSceneObject::CSceneObject(void)
{
}


CSceneObject::~CSceneObject(void)
{
}
