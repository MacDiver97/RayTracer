#include "StdAfx.h"
#include "Light.h"


CLight::CLight(void)
{
}


CLight::~CLight(void)
{
}
