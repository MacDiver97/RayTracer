#include "StdAfx.h"
#include "Camera.h"


CCamera::CCamera(void)
{
}


CCamera::~CCamera(void)
{
}
